import { useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";

function App() {
  const [text, setText] = useState("");
  const [engine, setEngine] = useState("deep_translator");
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);

  // ---------------- TRANSLATE ----------------
  const translateText = async () => {
    if (!text.trim()) {
      alert("Please enter text to translate");
      return;
    }

    try {
      setLoading(true);
      const res = await axios.post(
        "http://127.0.0.1:5000/translate",
        { text, engine }
      );
      setOutput(res.data.translated_text || "");
    } catch (err) {
      console.error("Translate error:", err);
      alert("Translate Error: " + (err.response?.data?.error || err.message));
    } finally {
      setLoading(false);
    }
  };

  // ---------------- FILE UPLOAD ----------------
  const uploadFile = async (e) => {
    try {
      const file = e.target.files[0];
      if (!file) return;

      const formData = new FormData();
      formData.append("file", file);

      setLoading(true);
      const res = await axios.post(
        "http://127.0.0.1:5000/upload-file",
        formData
      );

      setText(res.data.text || "");
    } catch (err) {
      console.error("Upload error:", err);
      alert("Upload Error: " + (err.response?.data?.error || err.message));
    } finally {
      setLoading(false);
    }
  };

  // ---------------- PRINT ----------------
  const printOutput = () => {
    if (!output.trim()) return;

    const printWindow = window.open("", "", "width=800,height=600");

    printWindow.document.write(`
      <html>
        <head>
          <title>Print</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
          </style>
        </head>
        <body>
          ${output}
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  // ---------------- DOWNLOAD ----------------
  const downloadFile = async (type) => {
    if (!output.trim()) return;

    try {
      const res = await axios.post(
        `http://127.0.0.1:5000/download/${type}`,
        { content: output },
        { responseType: "blob" }
      );

      const url = window.URL.createObjectURL(res.data);
      const a = document.createElement("a");
      a.href = url;
      a.download = `translation.${type}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Download error:", err);
      alert("Download Error: " + (err.response?.data?.error || err.message));
    }
  };

  // ---------------- UI ----------------
  return (
    <div className="d-flex justify-content-center align-items-center vh-100 w-100 bg-light">
      <div
        className="card p-4 shadow"
        style={{ width: "1550px", maxWidth: "37%" }}
      >
        <h4
          className="text-center fw-bold mb-3 py-2 rounded shadow-sm"
          style={{ backgroundColor: "green", color: "white" }}
        >
          Tamil Translator
        </h4>

        {/* Input Text */}
        <div className="mb-2">
          <label className="form-label fw-semibold small">
            Input Text
          </label>
          <textarea
            className="form-control form-control-sm"
            rows="3"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
        </div>

        {/* File Upload */}
        <div className="mb-3">
          <label className="form-label fw-semibold small">
            Upload File
          </label>
          <input
            type="file"
            className="form-control form-control-sm"
            onChange={uploadFile}
          />
        </div>

        {/* Translate Button */}
        <div className="text-center mb-3">
          <button
            className="btn btn-primary btn-sm px-4"
            onClick={translateText}
            disabled={loading}
          >
            {loading ? "Processing..." : "Translate"}
          </button>
        </div>

        {/* Output */}
        <div className="mb-3">
          <label className="form-label fw-semibold small">
            Translated Output
          </label>
          <textarea
            className="form-control form-control-sm"
            rows="4"
            value={output}
            onChange={(e) => setOutput(e.target.value)}
          />
        </div>

        {/* Action Buttons */}
        <div className="d-flex justify-content-between align-items-center">
          <button
            className="btn btn-outline-secondary btn-sm"
            onClick={printOutput}
            disabled={!output}
          >
            🖨 Print
          </button>

          <div className="dropdown">
            <button
              className="btn btn-primary btn-sm dropdown-toggle"
              type="button"
              data-bs-toggle="dropdown"
              disabled={!output}
            >
              ⬇ Download
            </button>

            <ul className="dropdown-menu dropdown-menu-end">
              <li>
                <button
                  className="dropdown-item"
                  onClick={() => downloadFile("docx")}
                >
                  DOCX
                </button>
              </li>
              <li>
                <button
                  className="dropdown-item"
                  onClick={() => downloadFile("pdf")}
                >
                  PDF
                </button>
              </li>
              <li>
                <button
                  className="dropdown-item"
                  onClick={() => downloadFile("odt")}
                >
                  ODT
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
