import { useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";

function App() {
  const [text, setText] = useState("");
  const [engine, setEngine] = useState("deep_translator");
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);

  // ---------------- TRANSLATE ----------------
  const translateText = async () => {
    if (!text.trim()) {
      alert("Please enter text to translate");
      return;
    }

    try {
      setLoading(true);
      const res = await axios.post(
        "http://127.0.0.1:5000/translate",
        { text, engine }
      );
      setOutput(res.data.translated_text || "");
    } catch (err) {
      alert("Translate Error: " + (err.response?.data?.error || err.message));
    } finally {
      setLoading(false);
    }
  };

  // ---------------- FILE UPLOAD ----------------
  const uploadFile = async (e) => {
    try {
      const file = e.target.files[0];
      if (!file) return;

      const formData = new FormData();
      formData.append("file", file);

      setLoading(true);
      const res = await axios.post(
        "http://127.0.0.1:5000/upload-file",
        formData
      );

      setText(res.data.text || "");
    } catch (err) {
      alert("Upload Error: " + (err.response?.data?.error || err.message));
    } finally {
      setLoading(false);
    }
  };

  // ---------------- PRINT ----------------
  const printOutput = () => {
    if (!output.trim()) return;

    const win = window.open("", "", "width=900,height=650");
    win.document.write(`
      <html>
        <head>
          <title>Print</title>
          <style>
            body { font-family: Arial; padding: 30px; }
          </style>
        </head>
        <body>${output}</body>
      </html>
    `);
    win.document.close();
    win.print();
  };

  // ---------------- DOWNLOAD (ODT ONLY) ----------------
  const downloadFile = async () => {
    if (!output.trim()) return;

    const res = await axios.post(
      "http://127.0.0.1:5000/download/odt",
      { content: output },
      { responseType: "blob" }
    );

    const url = URL.createObjectURL(res.data);
    const a = document.createElement("a");
    a.href = url;
    a.download = "translation.odt";
    a.click();
    URL.revokeObjectURL(url);
  };

  // ---------------- UI ----------------
  return (
    <div
      className="d-flex justify-content-center align-items-center min-vh-100"
      style={{
        width: "100vw",
        background: "linear-gradient(135deg, #f5f7fa, #c3cfe2)",
      }}
    >
      <div
        className="card border-0"
        style={{
          width: "1200px",
          maxWidth: "95%",
          padding: "35px",
          borderRadius: "16px",
          boxShadow: "0 20px 40px rgba(0,0,0,0.15)",
        }}
      >
        {/* Header */}
        <div
          className="text-center mb-4 py-3 rounded"
          style={{
            background: "linear-gradient(90deg, #0d6efd, #198754)",
            color: "white",
          }}
        >
          <h2 className="fw-bold mb-0">Tamil Translator</h2>
        </div>

        {/* Content */}
        <div className="row g-4">
          {/* Input */}
          <div className="col-md-6">
            <label className="fw-semibold mb-2">Input Text</label>
            <textarea
              className="form-control"
              rows="14"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter English text here..."
            />

            <label className="fw-semibold mt-3">Upload File</label>
            <input
              type="file"
              className="form-control"
              onChange={uploadFile}
            />

            <div className="text-center mt-4">
              <button
                className="btn btn-primary btn-lg px-5"
                onClick={translateText}
                disabled={loading}
              >
                {loading ? "Processing..." : "Translate"}
              </button>
            </div>
          </div>

          {/* Output */}
          <div className="col-md-6">
            <label className="fw-semibold mb-2">Translated Output</label>
            <textarea
              className="form-control"
              rows="14"
              value={output}
              onChange={(e) => setOutput(e.target.value)}
              placeholder="Translated Tamil text will appear here..."
            />

            <div className="d-flex justify-content-between mt-4">
              <button
                className="btn btn-outline-secondary"
                onClick={printOutput}
                disabled={!output}
              >
                Print
              </button>

              <button
                className="btn btn-success"
                onClick={downloadFile}
                disabled={!output}
              >
                Download ODT
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
