from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import os
import fitz
import pytesseract
from PIL import Image
import docx
from docx import Document
from docx.shared import Pt
from deep_translator import GoogleTranslator
from indic_transliteration.sanscript import transliterate, DEVANAGARI, TAMIL
from bs4 import BeautifulSoup
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph
from odf.opendocument import OpenDocumentText
from odf.text import P, Span
from odf.style import Style, TextProperties

app = Flask(__name__)
CORS(app)

# ---------------- FILE READERS ----------------

def read_txt(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def read_docx(path):
    doc = docx.Document(path)
    paragraphs = []
    for p in doc.paragraphs:
        text_runs = []
        for run in p.runs:
            run_text = run.text
            if run.bold:
                run_text = f"<b>{run_text}</b>"
            if run.italic:
                run_text = f"<i>{run_text}</i>"
            if run.underline:
                run_text = f"<u>{run_text}</u>"
            text_runs.append(run_text)
        paragraphs.append("".join(text_runs))
    return "\n".join(paragraphs)

def read_pdf(path):
    text = ""
    pdf = fitz.open(path)
    for page in pdf:
        text += page.get_text()
    return text

def read_image(path):
    img = Image.open(path)
    return pytesseract.image_to_string(img)

# ---------------- TRANSLATION ----------------

def chunk_text(text, max_chars=4000):
    chunks, current = [], ""
    for line in text.split("\n"):
        if len(current) + len(line) < max_chars:
            current += line + "\n"
        else:
            chunks.append(current)
            current = line + "\n"
    if current:
        chunks.append(current)
    return chunks

# ---------------- HTML CONVERTERS ----------------

def text_to_docx(text):
    soup = BeautifulSoup(text, "html.parser")
    doc = Document()
    for p_tag in soup.find_all("p") or [BeautifulSoup(f"<p>{text}</p>", "html.parser").p]:
        para = doc.add_paragraph()
        para.paragraph_format.space_after = Pt(6)
        for node in p_tag.children:
            if getattr(node, "name", None) == "b" or getattr(node, "name", None) == "strong":
                run = para.add_run(node.get_text())
                run.bold = True
            elif getattr(node, "name", None) == "i" or getattr(node, "name", None) == "em":
                run = para.add_run(node.get_text())
                run.italic = True
            elif getattr(node, "name", None) == "u":
                run = para.add_run(node.get_text())
                run.underline = True
            else:
                para.add_run(str(node))
    return doc

def text_to_odt(text):
    soup = BeautifulSoup(text, "html.parser")
    doc = OpenDocumentText()
    bold_style = Style(name="Bold", family="text")
    bold_style.addElement(TextProperties(fontweight="bold"))
    doc.styles.addElement(bold_style)

    italic_style = Style(name="Italic", family="text")
    italic_style.addElement(TextProperties(fontstyle="italic"))
    doc.styles.addElement(italic_style)

    underline_style = Style(name="Underline", family="text")
    underline_style.addElement(TextProperties(textunderlinestyle="solid"))
    doc.styles.addElement(underline_style)

    for p_tag in soup.find_all("p") or [BeautifulSoup(f"<p>{text}</p>", "html.parser").p]:
        p = P()
        for node in p_tag.children:
            if getattr(node, "name", None) == "b" or getattr(node, "name", None) == "strong":
                p.addElement(Span(stylename=bold_style, text=node.get_text()))
            elif getattr(node, "name", None) == "i" or getattr(node, "name", None) == "em":
                p.addElement(Span(stylename=italic_style, text=node.get_text()))
            elif getattr(node, "name", None) == "u":
                p.addElement(Span(stylename=underline_style, text=node.get_text()))
            else:
                p.addText(str(node))
        doc.text.addElement(p)
    return doc

# ---------------- ROUTES ----------------

@app.post("/translate")
def translate():
    data = request.json
    text = data.get("text", "")
    engine = data.get("engine", "deep_translator")
    if not text:
        return jsonify({"error": "No text provided"}), 400

    try:
        if engine == "deep_translator":
            translator = GoogleTranslator(source="en", target="ta")
            chunks = chunk_text(text)
            translated = "\n".join(translator.translate(c) for c in chunks)
        elif engine == "tamil_script_convert":
            dev = transliterate(text, "iast", DEVANAGARI)
            translated = transliterate(dev, DEVANAGARI, TAMIL)
        else:
            return jsonify({"error": "Invalid engine"}), 400
        return jsonify({"translated_text": translated})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.post("/upload-file")
def upload_file():
    file = request.files.get("file")
    if not file:
        return jsonify({"error": "No file uploaded"}), 400
    ext = file.filename.lower().split(".")[-1]
    temp_path = f"temp.{ext}"
    file.save(temp_path)
    try:
        if ext == "txt":
            text = read_txt(temp_path)
        elif ext == "docx":
            text = read_docx(temp_path)
        elif ext == "pdf":
            text = read_pdf(temp_path)
        elif ext in ["png", "jpg", "jpeg"]:
            text = read_image(temp_path)
        else:
            return jsonify({"error": "Unsupported file type"}), 400
        return jsonify({"text": text})
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

@app.post("/download/docx")
def download_docx():
    content = request.json.get("content", "")
    doc = text_to_docx(content)
    buffer = BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return send_file(buffer,
                     download_name="translation.docx",
                     as_attachment=True,
                     mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")

@app.post("/download/odt")
def download_odt():
    content = request.json.get("content", "")
    doc = text_to_odt(content)
    buffer = BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return send_file(buffer,
                     download_name="translation.odt",
                     as_attachment=True,
                     mimetype="application/vnd.oasis.opendocument.text")

@app.post("/download/pdf")
def download_pdf():
    content = request.json.get("content", "")
    soup = BeautifulSoup(content, "html.parser")
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []
    for p_tag in soup.find_all("p") or [BeautifulSoup(f"<p>{content}</p>", "html.parser").p]:
        story.append(Paragraph(p_tag.decode_contents(), styles["Normal"]))
        story.append(Paragraph("<br/>", styles["Normal"]))
    doc.build(story)
    buffer.seek(0)
    return send_file(buffer,
                     download_name="translation.pdf",
                     as_attachment=True,
                     mimetype="application/pdf")

# ---------------- MAIN ----------------

if __name__ == "__main__":
    app.run(debug=True)
